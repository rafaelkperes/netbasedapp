import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ServerSocket server = new ServerSocket(9999);
		InputStream in = null;
		OutputStream out = null;
		Socket client = null;

		System.out.print("Server listening...");
		client = server.accept();
		in = client.getInputStream();
		out = new FileOutputStream("video.mp4");

		byte[] bytes = new byte[16 * 1024];

		int count;
		while ((count = in.read(bytes)) > 0) {
			out.write(bytes, 0, count);
		}
		out.close();
		in.close();
		client.close();
		server.close();
	}
}
