import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class Client {
	private static KeyPair kpA = null;
	private static Cipher rsa = null;
	private static Cipher aes = null;
	private static byte cipherBytes[], plainBytes[];

	private static final String PUBLIC_A_KEY_PATH = "key_a.public";
	private static final String PRIVAT_A_KEY_PATH = "key_a.privat";
	private static PublicKey public_key_A = null;
	private static PrivateKey private_key_A = null;

	private static final String PUBLIC_B_KEY_PATH = "key_b.public";
	private static PublicKey public_key_B = null;

	private static SecretKeySpec aes_key_spec = null;
	private static SecretKey secretKey = null;

	public static void main(String[] args)
			throws UnknownHostException, IOException, ClassNotFoundException, GeneralSecurityException {
		KeyPair kpB = null;
		InputStream in = null;
		OutputStream out = null;
		secretKey = KeyGenerator.getInstance("AES").generateKey();

		System.out.print("Client started...");

		sendAESKey();
		sendVideo("video.mp4");

	}

	private static void sendAESKey() throws IOException, NoSuchAlgorithmException, ClassNotFoundException {
		// create new key
		Socket server = new Socket("localhost", 9999);
		String originalText = "Text to be encrypted ";
		ObjectInputStream inputStream = null;

		// get base64 encoded version of the key
		String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
		originalText = encodedKey;
		// System.out.println(originalText);
		// Encrypt the string using the public key
		inputStream = new ObjectInputStream(new FileInputStream(PUBLIC_B_KEY_PATH));
		final PublicKey publicKey = (PublicKey) inputStream.readObject();
		final byte[] cipherText = encrypt(originalText, publicKey);
		FileOutputStream fos = new FileOutputStream("AESKey");
		fos.write(cipherText);
		fos.close();

		File file = new File("AESKey");
		InputStream in = new FileInputStream(file);
		OutputStream outt = server.getOutputStream();

		copy(in, outt);
		outt.close();
		in.close();
		server.close();
	}

	private static void sendVideo(String fileType)
			throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
		Socket server = new Socket("localhost", 9999);
		File videoFile = new File(fileType);
		InputStream in = new FileInputStream(videoFile);
		OutputStream out = server.getOutputStream();

		aes = Cipher.getInstance("AES");
		aes.init(Cipher.ENCRYPT_MODE, secretKey);
		CipherOutputStream os = new CipherOutputStream(out, aes);

		copy(in, os);
		out.close();
		in.close();
		server.close();
	}

	public static byte[] encrypt(String text, PublicKey key) {
		byte[] cipherText = null;
		try {
			// get an RSA cipher object and print the provider
			final Cipher cipher = Cipher.getInstance("RSA");
			// encrypt the plain text using the public key
			cipher.init(Cipher.ENCRYPT_MODE, key);
			cipherText = cipher.doFinal(text.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cipherText;
	}

	private static void copy(InputStream is, OutputStream os) throws IOException {
		int i;
		byte[] b = new byte[16 * 1024];
		while ((i = is.read(b)) != -1) {
			os.write(b, 0, i);
		}
	}
}
