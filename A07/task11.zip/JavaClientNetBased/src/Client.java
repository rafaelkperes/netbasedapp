import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class Client {
	private static KeyPair kpA = null;
	private static Cipher rsa = null;
	private static Cipher aes = null;
	private static byte cipherBytes[], plainBytes[];

	private static final String PUBLIC_A_KEY_PATH = "key_a.public";
	private static final String PRIVAT_A_KEY_PATH = "key_a.privat";
	private static PublicKey public_key_A = null;
	private static PrivateKey private_key_A = null;

	private static final String PUBLIC_B_KEY_PATH = "key_b.public";
	private static PublicKey public_key_B = null;

	private static SecretKeySpec aes_key_spec = null;
	private static SecretKey secretKey = null;

	public static void main(String[] args)
			throws UnknownHostException, IOException, ClassNotFoundException, GeneralSecurityException {
		KeyPair kpB = null;
		InputStream in = null;
		OutputStream out = null;
		secretKey = KeyGenerator.getInstance("AES").generateKey();
		getRSAKeys();

		System.out.print("Client started...");

		sendAESKey();
		sendVideo("video.mp4");

	}

	private static void sendAESKey()
			throws IOException, NoSuchAlgorithmException, ClassNotFoundException {
		// create new key
		Socket server = new Socket("localhost", 9999);
		String originalText = "Text to be encrypted ";
		ObjectInputStream inputStream = null;

		// get base64 encoded version of the key
		String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
		originalText = encodedKey;
		System.out.println(originalText);
		// Encrypt the string using the public key
		inputStream = new ObjectInputStream(new FileInputStream(PUBLIC_B_KEY_PATH));
		final PublicKey publicKey = (PublicKey) inputStream.readObject();
		final byte[] cipherText = encrypt(originalText, publicKey);
		FileOutputStream fos = new FileOutputStream("AESKey");
		fos.write(cipherText);
		fos.close();

		File file = new File("AESKey");
		byte[] bytes = new byte[16 * 1024];
		InputStream in = new FileInputStream(file);
		OutputStream outt = server.getOutputStream();

		int count;
		while ((count = in.read(bytes)) > 0) {
			outt.write(bytes, 0, count);
		}
		outt.close();
		in.close();
		server.close();
	}

	private static void sendVideo(String fileType)
			throws IOException {
		Socket server = new Socket("localhost", 9999);
		byte[] bytes = new byte[16 * 1024];
		File videoFile = new File(fileType);
		InputStream in = new FileInputStream(videoFile);
		OutputStream out = server.getOutputStream();
		int count;
		while ((count = in.read(bytes)) > 0) {
			out.write(bytes, 0, count);
		}
		out.close();
		in.close();
		server.close();
	}

	private static void getRSAKeys() throws IOException, ClassNotFoundException {
		FileInputStream fisRSA;
		fisRSA = new FileInputStream(PUBLIC_A_KEY_PATH);
		ObjectInputStream inRSA = new ObjectInputStream(fisRSA);
		public_key_A = (PublicKey) inRSA.readObject();
		inRSA.close();

		fisRSA = new FileInputStream(PRIVAT_A_KEY_PATH);
		inRSA = new ObjectInputStream(fisRSA);
		private_key_A = (PrivateKey) inRSA.readObject();
		inRSA.close();

		fisRSA = new FileInputStream(PUBLIC_B_KEY_PATH);
		inRSA = new ObjectInputStream(fisRSA);
		public_key_B = (PublicKey) inRSA.readObject();
		inRSA.close();
	}

	/**
	 * Encrypt the plain text using public key.
	 * 
	 * @param text
	 *            : original plain text
	 * @param key
	 *            :The public key
	 * @return Encrypted text
	 * @throws java.lang.Exception
	 */
	public static byte[] encrypt(String text, PublicKey key) {
		byte[] cipherText = null;
		try {
			// get an RSA cipher object and print the provider
			final Cipher cipher = Cipher.getInstance("RSA");
			// encrypt the plain text using the public key
			cipher.init(Cipher.ENCRYPT_MODE, key);
			cipherText = cipher.doFinal(text.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cipherText;
	}
}
