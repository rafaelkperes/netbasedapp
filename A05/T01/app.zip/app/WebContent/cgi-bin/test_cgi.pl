#!/usr/bin/perl
 
print ("Content-type: text/html\n\n");
$now = localtime();
 
print "<h1>It really is<h1>$now";